<?php

namespace Incentives\OrdenesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesOrdenesBundle extends Bundle
{
}
