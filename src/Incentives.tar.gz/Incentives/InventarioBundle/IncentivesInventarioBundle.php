<?php

namespace Incentives\InventarioBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesInventarioBundle extends Bundle
{
}
