<?php

namespace Incentives\RedencionesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesRedencionesBundle extends Bundle
{
}
