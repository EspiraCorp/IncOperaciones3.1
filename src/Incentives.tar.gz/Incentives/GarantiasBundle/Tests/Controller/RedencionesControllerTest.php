<?php

namespace Incentives\GarantiasBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class RedencionesControllerTest extends WebTestCase
{
}
