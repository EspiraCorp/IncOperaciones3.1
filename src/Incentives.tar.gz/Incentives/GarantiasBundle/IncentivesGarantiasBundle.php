<?php

namespace Incentives\GarantiasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesGarantiasBundle extends Bundle
{
}
