<?php

namespace Incentives\OperacionesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncentivesOperacionesBundle extends Bundle
{
}
