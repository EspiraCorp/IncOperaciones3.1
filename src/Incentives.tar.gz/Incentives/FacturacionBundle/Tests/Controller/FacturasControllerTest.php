<?php

namespace Incentives\FacturacionBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class FacturasControllerTest extends WebTestCase
{
}
